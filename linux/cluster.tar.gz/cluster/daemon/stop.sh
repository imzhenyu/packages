pid=$(cat pid)
kill -9 $pid

