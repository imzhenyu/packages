package_server_host=srgssd-06
package_server_port=24601
package_dir=/home/zhenyug/projects/rDSN/src/tools/webstudio/app_package/local/packages
ports=24801
meta_server_list=srgssd-06:24601
./dsn.svchost config.ini -cargs package_server_host=${package_server_host}\;package_server_port=${package_server_port}\;package_dir=${package_dir}\;ports=${ports}\;meta_server_list=${meta_server_list}\; &
echo $!>pid
