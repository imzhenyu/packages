ports=24601
./dsn.svchost config.ini -cargs ports=${ports}\; &
echo $!>pid
